import { Question } from './../../interface/question';
import { Component, OnInit } from '@angular/core';
import { Quiz } from 'src/app/interface/quiz';
import { ApiService } from 'src/app/service/api.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  favoriteSeason!: string;
  seasons: string[] = ['has sit', 'has been sit', 'has been sitting', 'sitting'];
  quiz !: Quiz;
  quizForm !: FormGroup;


  question:any;  //for show
  current_ques_id!:number;


  constructor(
    private api : ApiService,
    private formBuilder : FormBuilder
  ) { }


  ngOnInit(): void {
    // this.quizForm = this.formBuilder.group({

    // })
    this.getQuiz();
  }

  getQuiz() {
    this.api.getQuizById(9).subscribe({
      next: (data) => {
        this.quiz = data;
        this.quiz.questions.forEach(element => {
          console.log(element.answer);
        })
      }
    })
  }

}
